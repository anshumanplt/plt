<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Razorpay\Api\Api;

class RazorpayController extends Controller
{
    public function createOrder()
    {
   
        $api = new Api(config('RAZORPAY_KEY'), config('RAZORPAY_SECRET'));

        $order = $api->order->create([
            'amount' => 500, // Order amount in paise
            'currency' => 'INR',
            'payment_capture' => 1 // Auto-capture payment
        ]);

        $orderId = $order->id;

        return view('razorpay.payment', compact('orderId', 'orderAmount'));
    }
}
