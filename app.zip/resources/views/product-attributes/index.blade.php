@extends('layouts.app') <!-- Use your own layout if available -->

@section('content')
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Product Attributes</h1>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <a href="{{ route('product-attributes.create', $productId) }}">Add variant to product</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Attribute</th>
                    <th>Attribute Value</th>
                    <th>Price</th>
                    <th>Inventory</th>
                    <!-- Add more table headers for other attributes -->
                </tr>
            </thead>
            <tbody>
                @foreach($productAttributes as $attribute)
                    <tr>
                        <td>{{ $attribute->product->name }}</td>
                        <td>{{ $attribute->attribute->name }}</td>
                        <td>{{ $attribute->attributeValues->value }}</td>
                        <td>{{ $attribute->price }}</td>
                        <td>{{ $attribute->inventory }}</td>
                        <!-- Add more table cells for other attributes -->
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    </div></div>
@endsection
