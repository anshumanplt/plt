 

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        <div class="container">
            <h2>Create Product Attribute</h2>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('product-attributes.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($productId); ?>">
                <?php $__currentLoopData = $allAttribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for=""><?php echo e($value->name); ?></label>
                        <select name="attributes[]" class="form-control" id="">
                            <option value="">-- Select option --</option>
                            <?php $__currentLoopData = $value->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>:<?php echo e($item->id); ?>"><?php echo e($item->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label for="">Product Images</label>
                    <input type="file" class="form-control" name="files" multiple id="">
                </div>
                
                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="number" name="price" id="price" class="form-control">
                </div>

                <div class="form-group">
                    <label for="inventory">Inventory:</label>
                    <input type="number" name="inventory" id="inventory" class="form-control">
                </div>

                
                <button type="submit" class="btn btn-primary">Create Product Attribute</button>
            </form>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<script>
$(document).ready(function () {
    $('#attribute_id').on('change', function () {
        var selectedAttribute = $(this).val();
        var attributeValuesDropdown = $('#attribute-values');

        if (selectedAttribute) {
            $.ajax({
                url: "<?php echo e(route('get-attribute-values')); ?>",
                type: "GET",
                data: { attribute_id: selectedAttribute },
                success: function (response) {

                    var attributeValues = response.attribute_values;

                    console.log("Check AttributeValue : ");
                    console.log(attributeValues);

                    // Clear previous options
                    attributeValuesDropdown.empty();
                    attributeValuesDropdown.append('<option value="">Select an Attribute Value</option>');

                    // Add new options
                    attributeValues.forEach(function (value) {
                        attributeValuesDropdown.append('<option value="' + value.id + '">' + value.value + '</option>');
                    });
                },
                error: function (error) {
                    console.error(error);
                }
            });
        } else {
            // Clear the attribute values dropdown if no attribute is selected
            attributeValuesDropdown.empty();
            attributeValuesDropdown.append('<option value="">Select an Attribute</option>');
        }
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/product-attributes/create.blade.php ENDPATH**/ ?>