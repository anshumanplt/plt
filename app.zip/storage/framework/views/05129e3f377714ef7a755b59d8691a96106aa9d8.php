<!-- resources/views/brands/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Brand Details</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($brand->name); ?></h5>

                <div class="mb-3">
                    <label class="fw-bold">ID:</label>
                    <span><?php echo e($brand->id); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Title:</label>
                    <span><?php echo e($brand->meta_title); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Description:</label>
                    <span><?php echo e($brand->meta_description); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Keywords:</label>
                    <span><?php echo e($brand->meta_keywords); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Image:</label>
                    <?php if($brand->image): ?>
                        <img src="<?php echo e(asset('storage/' . $brand->image)); ?>" alt="Brand Image" width="200">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </div>

                <a href="<?php echo e(route('brands.edit', $brand->id)); ?>" class="btn btn-primary">Edit</a>
                <a href="<?php echo e(route('brands.index')); ?>" class="btn btn-secondary">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/brands/show.blade.php ENDPATH**/ ?>