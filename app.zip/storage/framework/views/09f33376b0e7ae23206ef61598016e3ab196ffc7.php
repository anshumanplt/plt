

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Product Images</h1>

        <div class="image-list">
            <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="image-item">
                    <img src="<?php echo e(asset('../storage/app/public/'.$image->image_path)); ?>" class="img-responsive" height="100" width="300" alt="Product Image">


                    <div class="image-details">
                        <p>Status: <?php echo e($image->status ? 'Active' : 'Inactive'); ?></p>
                        <p>Featured: <?php echo e($image->featured ? 'Yes' : 'No'); ?></p>
                    </div>
                    <div class="image-actions">
                        
                        <a href="<?php echo e(url('products/images/feature', [$product->id, $image->id])); ?>">is Featured Image </a>
                        <form action="<?php echo e(route('products.images.destroy', [$product->id, $image->id])); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this image?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-delete">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No product images available.</p>
            <?php endif; ?>
        </div>
        <a href="<?php echo e(route('products.images.create', $product->id)); ?>" class="btn btn-primary">Add Image</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/product_images/index.blade.php ENDPATH**/ ?>