
<?php $__env->startSection('content'); ?>
      <!-- Breadcrumb Begin -->
      <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->
<div class="container">
    
    <div class="row">
        <div class="col-md-3">
            <?php echo $__env->make('myaccount_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-9">
            <h2>My Orders</h2>
            <table class="table">
                <tr>
                    <td>Order Id</td>
                    <td>Total Amount</td>
                    <td>Payment Method</td>
                    <td>Shipping Address</td>
                    <td>Status</td>
                    <td>Action</td>



                </tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($order->id); ?></td>
                        <td> ₹<?php echo e($order->total_amount); ?></td>
                        <td><?php echo e($order->payment_method); ?></td>
                        <td> <p><?php echo e($order->address->address1); ?></p>
                            <p><?php echo e($order->address->address2); ?></p>
                            <p><?php echo e($order->address->city); ?>, <?php echo e($order->address->state); ?>, <?php echo e($order->address->country); ?></p></td>
                        <td><?php echo e($order->order_state); ?></td>
                        <td><a href="<?php echo e(route('orders.show', $order->id)); ?>">View Details</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/orders/index.blade.php ENDPATH**/ ?>