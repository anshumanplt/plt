<!-- resources/views/attribute_values/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Attribute Value Details</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($attributeValue->value); ?></h5>

                <div class="mb-3">
                    <label class="fw-bold">ID:</label>
                    <span><?php echo e($attributeValue->id); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Attribute:</label>
                    <span><?php echo e($attributeValue->attribute->name); ?></span>
                </div>

                <a href="<?php echo e(route('attribute_values.edit', $attributeValue->id)); ?>" class="btn btn-primary">Edit</a>
                <a href="<?php echo e(route('attribute_values.index')); ?>" class="btn btn-secondary">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/attribute_values/show.blade.php ENDPATH**/ ?>