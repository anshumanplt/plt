<!-- resources/views/attribute_values/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Attribute Values</h1>

        <a href="<?php echo e(route('attribute_values.create')); ?>" class="btn btn-primary">Create New Attribute Value</a>

        <table class="table mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Attribute</th>
                    <th>Value</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attributeValue->id); ?></td>
                        <td><?php echo e($attributeValue->attribute->name); ?></td>
                        <td><?php echo e($attributeValue->value); ?></td>
                        <td>
                            <a href="<?php echo e(route('attribute_values.show', $attributeValue->id)); ?>" class="btn btn-sm btn-info">View</a>
                            <a href="<?php echo e(route('attribute_values.edit', $attributeValue->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('attribute_values.destroy', $attributeValue->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this attribute value?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/attribute_values/index.blade.php ENDPATH**/ ?>