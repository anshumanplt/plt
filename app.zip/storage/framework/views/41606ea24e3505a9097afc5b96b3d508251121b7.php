 <!-- Use your own layout if available -->

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Product Attributes</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('product-attributes.create', $productId)); ?>">Add variant to product</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Attribute</th>
                    <th>Attribute Value</th>
                    <th>Price</th>
                    <th>Inventory</th>
                    <!-- Add more table headers for other attributes -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attribute->product->name); ?></td>
                        <td><?php echo e($attribute->attribute->name); ?></td>
                        <td><?php echo e($attribute->attributeValues->value); ?></td>
                        <td><?php echo e($attribute->price); ?></td>
                        <td><?php echo e($attribute->inventory); ?></td>
                        <!-- Add more table cells for other attributes -->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/product-attributes/index.blade.php ENDPATH**/ ?>