
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="search-result">
        <a href="<?php echo e(url('/product-detail')); ?>/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a>
        <!-- Display other product details here -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/partials/search_results.blade.php ENDPATH**/ ?>