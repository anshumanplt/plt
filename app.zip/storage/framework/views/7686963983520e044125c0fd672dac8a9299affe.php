
<?php $__env->startSection('content'); ?>
      <!-- Breadcrumb Begin -->
      <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container" style="min-height: 450px;">
    
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('myaccount_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <h2>My Accounts</h2>
            
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/orders/myaccount.blade.php ENDPATH**/ ?>