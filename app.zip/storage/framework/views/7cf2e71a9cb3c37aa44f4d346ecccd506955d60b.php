<!-- resources/views/admin/users/index.blade.php -->

 

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        <div class="container">
            <h1>Admin Users</h1>


            <a href="<?php echo e(route('admin-users.create')); ?>" class="btn btn-primary mb-3">Create Admin User</a>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $adminUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($adminUser->name); ?></td>
                            <td><?php echo e($adminUser->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin-users.show', $adminUser->id)); ?>" class="btn btn-info">View</a>
                                <a href="<?php echo e(route('admin-users.edit', $adminUser->id)); ?>" class="btn btn-warning">Edit</a>
                           
                                  <!-- Delete form -->

                                    <form action="<?php echo e(route('admin-users.destroy', $adminUser->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                    </form>
                         
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($adminUsers->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/admin/users/index.blade.php ENDPATH**/ ?>