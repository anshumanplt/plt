<!-- resources/views/categories/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Categories</h1>

        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Create New Category</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Category ID</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Parent ID</th>
                    
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($category->category_id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php if($category->image): ?><img src="<?php echo e(asset('images/categories/' . $category->image)); ?>" alt="Category Image" width="100">  <?php else: ?> NA <?php endif; ?></td>
                        <td><?php if($category->parent): ?><?php echo e($category->parent->name); ?> <?php else: ?> NA  <?php endif; ?></td>
                        
                        <td><?php echo e($category->status ? 'Active' : 'Inactive'); ?></td>
                        <td>
                            <a href="<?php echo e(route('categories.show', $category->category_id)); ?>" class="btn btn-sm btn-info">View</a>
                            <a href="<?php echo e(route('categories.edit', $category->category_id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('categories.destroy', $category->category_id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this category?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/categories/index.blade.php ENDPATH**/ ?>