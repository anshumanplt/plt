<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ashion Template">
    <meta name="keywords" content="Ashion, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Prettylovingthing</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cookie&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
    rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/elegant-icons.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/jquery-ui.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/frontend/css/style.css')); ?>" type="text/css">
 
 <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />

</head>

<body>
    <style>
        .search-results-container {
            max-height: 300px; /* Set the maximum height for the scrollable container */
            overflow-y: auto; /* Add vertical scrollbar when content exceeds container height */
            border: 1px solid #ccc; /* Add a border for clarity */
        }
    </style>
    <!-- Page Preloder -->
    

    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__close">+</div>
        <ul class="offcanvas__widget">
            <li><span class="icon_search search-switch"></span></li>
            <?php if(Auth::check()): ?>
            <li><a href="<?php echo e(url('/wishlist')); ?>"><span class="icon_heart_alt"></span>
                <div class="tip">   <?php 
                    $wishlist = \App\Models\Wishlist::where('user_id', Auth::user()->id)->get();
                    echo count($wishlist);
                    ?></div>
            </a></li>
            <?php endif; ?>
            <li><a href="<?php echo e(url('/cart')); ?>"><span class="icon_bag_alt"></span>
                <div class="tip">
                    <?php if(Auth::check()): ?>
                    <?php 
                    $cartValue = \App\Models\Cart::get();
                    echo count($cartValue);
                    ?>
                        <?php else: ?>
                            <?php echo e(session('guest_cart') ? count(session('guest_cart')) : 0); ?>

                    <?php endif; ?>
                </div>
            </a></li>
            
        </ul>
        <div class="offcanvas__logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/frontend/img/1657366295logo.png')); ?>" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <div class="offcanvas__auth">
            <a href="<?php echo e(url('/login')); ?>">Login</a>
            <a href="<?php echo e(url('/register')); ?>">Register</a>
        </div>
    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-2">
                    <div class="header__logo">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/frontend/img/1657366295logo.png')); ?>" alt=""></a>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-7">
                    <nav class="header__menu">
                        <ul>
                            
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('category')); ?>/<?php echo e($item->category_id); ?>"><?php echo e($item->name); ?></a>
                                    <?php 
                                        if(count($item->submenu) > 0) {
                                            ?>
                                                <ul class="dropdown">
                                                    <?php $__currentLoopData = $item->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url('category')); ?>/<?php echo e($submenu->category_id); ?>"><?php echo e($submenu->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php
                                        }    
                                    ?>

                                </li>   
  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            
                            
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="header__right">
                        <?php if(!Auth::check()): ?>
                                <div class="header__right__auth">
                                    <a href="<?php echo e(url('/login')); ?>">Login</a>
                                    <a href="<?php echo e(url('/register')); ?>">Register</a>
                                </div>
                            <?php else: ?>
                            <div class="header__right__auth">
                                <a href="<?php echo e(url('/my-account')); ?>">My account</a>
                                
                                <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                                 <?php echo e(__('Logout')); ?>

                             </a>

                             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                 <?php echo csrf_field(); ?>
                             </form>
                            </div>
                        <?php endif; ?>

                        <ul class="header__right__widget">
                            <li><span class="icon_search search-switch"></span></li>
                            <?php if(Auth::check()): ?>
                            <li><a href="<?php echo e(url('/wishlist')); ?>"><span class="icon_heart_alt"></span>
                                <div class="tip">
                                    <?php 
                                    $wishlist = \App\Models\Wishlist::where('user_id', Auth::user()->id)->get();
                                    echo count($wishlist);
                                    ?>
                                </div>
                            </a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(url('/cart')); ?>"><span class="icon_bag_alt"></span>
                                <div class="tip">  
                                    <?php if(Auth::check()): ?>
                                    <?php 
                                    $cartValue = \App\Models\Cart::get();
                                    echo count($cartValue);
                                    ?>
                                        <?php else: ?>
                                            <?php echo e(session('guest_cart') ? count(session('guest_cart')) : 0); ?>

                                    <?php endif; ?>
                                    </div>
                            </a></li>
                            
                        </ul>

                    </div>
                </div>
            </div>
            <div class="canvas__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Instagram Begin -->
<div class="instagram">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-1.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-2.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-3.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-4.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-5.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                <div class="instagram__item set-bg" data-setbg="<?php echo e(url('/frontend/img/instagram/insta-6.jpg')); ?>">
                    <div class="instagram__text">
                        <i class="fa fa-instagram"></i>
                        <a href="#">@ ashion_shop</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Instagram End -->

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-7">
                <div class="footer__about">
                    <div class="footer__logo">
                        <a href="<?php echo e(url('/')); ?>"><img src="img/logo.png" alt=""></a>
                    </div>
                    <p>We are Pretty Loving Thing. The brand behind fashion Freedom.We exist for the love of fashion. We have got all the permimum range of outfits you could ever need in life. from ”designer fashion for women to the latest trends in women’s fashion” From date night dress to ritual colection.</p>
                    <div class="footer__payment">
                        <a href="#"><img src="img/payment/payment-1.png" alt=""></a>
                        <a href="#"><img src="img/payment/payment-2.png" alt=""></a>
                        <a href="#"><img src="img/payment/payment-3.png" alt=""></a>
                        <a href="#"><img src="img/payment/payment-4.png" alt=""></a>
                        <a href="#"><img src="img/payment/payment-5.png" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-5">
                <div class="footer__widget">
                    <h6>Quick links</h6>
                    <ul>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Blogs</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4">
                <div class="footer__widget">
                    <h6>Account</h6>
                    <ul>
                        <li><a href="#">My Account</a></li>
                        <li><a href="#">Orders Tracking</a></li>
                        <li><a href="#">Checkout</a></li>
                        <li><a href="#">Wishlist</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-8 col-sm-8">
                <div class="footer__newslatter">
                    <h6>NEWSLETTER</h6>
                    <form action="#">
                        <input type="text" placeholder="Email">
                        <button type="submit" class="site-btn">Subscribe</button>
                    </form>
                    <div class="footer__social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                <div class="footer__copyright__text">
                    <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved <a href="https://prettylovingthing.com" target="_blank">Prettylovingthing</a></p>
                </div>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->

<!-- Search Begin -->
<div class="search-model">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-switch">+</div>
        <form class="search-model-form" id="searchForm">
            <input type="text" id="searchQuery" placeholder="Search for products">
        </form>
        <div class="search-results-container">
            <div id="searchResults"></div>
        </div>
    </div>
</div>
<!-- Search End -->

<!-- Js Plugins -->
<script src="<?php echo e(url("/frontend/js/jquery-3.3.1.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/jquery.magnific-popup.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/jquery-ui.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/mixitup.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/jquery.countdown.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/jquery.slicknav.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/owl.carousel.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/jquery.nicescroll.min.js")); ?>"></script>
<script src="<?php echo e(url("/frontend/js/main.js")); ?>"></script>
   
   <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>


<script>
    $(document).ready(function() {
        toastr.options.timeOut = 10000;
        <?php if(Session::has('error')): ?>
            toastr.error('<?php echo e(Session::get('error')); ?>');
        <?php elseif(Session::has('success')): ?>
            toastr.success('<?php echo e(Session::get('success')); ?>');
        <?php endif; ?>
    });

</script>
<script>
    $(document).ready(function() {
        $('#country_id').change(function() {
            var countryId = $(this).val();

            $.ajax({
                url: '/get-states/' + countryId,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    var $stateSelect = $('#state_id');
                    $stateSelect.empty();

                    $.each(data, function(key, state) {
                        $stateSelect.append('<option value="' + state.id + '">' + state.name + '</option>');
                    });
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#state_id').change(function() {
            var stateId = $(this).val();

            $.ajax({
                url: '/get-cities/' + stateId,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    var $citySelect = $('#city_id');
                    $citySelect.empty();

                    $.each(data, function(key, city) {
                        $citySelect.append('<option value="' + city.id + '">' + city.name + '</option>');
                    });
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function () {
        $('#searchQuery').on('keyup', function () {
            var query = $(this).val();

            $('#searchResults').html('<p>Loading...</p>'); // Display loading indicator

            $.ajax({
                url: "<?php echo e(route('search')); ?>",
                method: "GET",
                data: { query: query },
                success: function (data) {
                    $('#searchResults').html(data);
                }
            });
        });
    });
</script>
</body>

</html><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/layouts/frontlayout.blade.php ENDPATH**/ ?>