
<?php $__env->startSection('content'); ?>

    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
                        
                        <span><?php echo e($product->name); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Product Details Section Begin -->
    <section class="product-details spad">
        <div class="container">
            <div class="row">
              
                <div class="col-lg-6">
                    <div class="product__details__pic">
                        <div class="product__details__pic__left product__thumb nice-scroll">
                            <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="pt active" href="#product-<?php echo e($key); ?>">
                                    <img src="<?php echo e(asset('../storage/app/public/'.$item->image_path)); ?>" alt="">
                                </a>                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            
                        </div>
                        <div class="product__details__slider__content">
                            <div class="product__details__pic__slider owl-carousel">
                                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img data-hash="product-<?php echo e($key); ?>" class="product__big__img" src="<?php echo e(asset('../storage/app/public/'.$item->image_path)); ?>" alt="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="col-sm-12">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    </div>
                    <div class="product__details__text">
                        <h3><?php echo e($product->name); ?></h3>
                        <div class="rating">
                            
                        </div>
                        <div class="product__details__price">₹ <?php echo e($product->sale_price); ?><span>₹ <?php echo e($product->price); ?></span></div>
                        <p><?php echo e($product->description); ?></p>
                        <div class="product__details__button">
                            
                            <a href="<?php echo e(url('/cart/add')); ?>/<?php echo e($product->id); ?>" class="cart-btn"><span class="icon_bag_alt"></span> Add to cart</a>
                            <ul>
                               

                                <?php if(Auth::check()): ?>
                                    <?php 
                                        $wishlist = \App\Models\Wishlist::where(['user_id' => Auth::user()->id, 'product_id' => $product->id])->first();
                                        
                                    ?>
                                        <?php if($wishlist): ?> 
                                            <li><a href="<?php echo e(route('wishlist.remove', $wishlist->id)); ?>"><span class="icon_heart_alt" style="color: red;"></span></a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('/wishlist/add')); ?>/<?php echo e($product->id); ?>"><span class="icon_heart_alt"></span></a></li>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <li><a href="<?php echo e(url('/wishlist/add')); ?>/<?php echo e($product->id); ?>"><span class="icon_heart_alt"></span></a></li>
                                <?php endif; ?>

                                
                            </ul>
                        </div>
                        <div class="product__details__widget">
                            <ul>
                                

                                <?php $__currentLoopData = $allAttribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <span><?php echo e($item->name); ?>:</span>
                                        <div class="checkbox">
                                            <?php $__currentLoopData = $item->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label for="">
                                                    <label for=""><?php echo e($value->value); ?></label>   
                                                    <input type="radio" name="<?php echo e($item->name); ?>" id="" >
                                                    <span class="checkmark"></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                           
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             
                             
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__details__tab">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Description</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Specification</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">Reviews ( 2 )</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="tabs-1" role="tabpanel">
                                <h6>Description</h6>
                                <p><?php echo e($product->description); ?></p>
                               
                            </div>
                            <div class="tab-pane" id="tabs-2" role="tabpanel">
                                <h6>Specification</h6>
                                <p>NA</p>
                            </div>
                            <div class="tab-pane" id="tabs-3" role="tabpanel">
                                <h6>Reviews ( 2 )</h6>
                                <p>NA</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="related__title">
                        <h5>RELATED PRODUCTS</h5>
                    </div>
                </div>
                <?php $__currentLoopData = $relatedProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="product__item">
                        <div class="product__item__pic set-bg" data-setbg="<?php if(count($item->productImages) > 0): ?><?php echo e(asset('../storage/app/public/'.$item->productImages[0]->image_path)); ?> <?php endif; ?>">
                            <div class="label new">New</div>
                            <ul class="product__hover">
                                <li><a href="<?php if(count($item->productImages) > 0): ?><?php echo e(asset('../storage/app/public/'.$item->productImages[0]->image_path)); ?> <?php endif; ?>" class="image-popup"><span class="arrow_expand"></span></a></li>
                                <?php if(Auth::check()): ?>
                                    <?php 
                                        $wishlist = \App\Models\Wishlist::where(['user_id' => Auth::user()->id, 'product_id' => $item->id])->first();
                                        
                                    ?>
                                        <?php if($wishlist): ?> 
                                            <li><a href="<?php echo e(route('wishlist.remove', $wishlist->id)); ?>"><span class="icon_heart_alt" style="color: red;"></span></a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('/wishlist/add')); ?>/<?php echo e($product->id); ?>"><span class="icon_heart_alt"></span></a></li>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <li><a href="<?php echo e(url('/wishlist/add')); ?>/<?php echo e($item->id); ?>"><span class="icon_heart_alt"></span></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="product__item__text">
                            <h6><a href="<?php echo e(url('/product-detail')); ?>/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h6>
                            <div class="rating">
                                
                            </div>
                            <div class="product__price">₹ <?php echo e($item->sale_price); ?><span>₹ <?php echo e($item->price); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            
            </div>
        </div>
    </section>
    <!-- Product Details Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/product_detail.blade.php ENDPATH**/ ?>