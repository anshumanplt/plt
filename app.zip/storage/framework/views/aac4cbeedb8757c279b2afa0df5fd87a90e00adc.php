

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Add Product Image</h1>

        <form action="<?php echo e(route('products.images.store', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" name="images[]" multiple id="image" class="form-control">
            </div>

            <div class="form-group">
                <label for="featured">Featured</label>
                <input type="checkbox" name="featured" id="featured" value="1" class="form-check-input">
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <input type="checkbox" name="status" id="status" value="1" class="form-check-input" checked>
            </div>

            <button type="submit" class="btn btn-primary">Add Image</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/product_images/create.blade.php ENDPATH**/ ?>