<!-- resources/views/brands/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Brands</h1>

        <a href="<?php echo e(route('brands.create')); ?>" class="btn btn-primary">Create New Brand</a>

        <table class="table mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Meta Title</th>
                    <th>Meta Description</th>
                    <th>Meta Keywords</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($brand->id); ?></td>
                        <td><?php echo e($brand->name); ?></td>
                        <td>
                            <?php if($brand->image): ?>
                                <img src="<?php echo e(asset('storage/' . $brand->image)); ?>" alt="Brand Image" width="100">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($brand->meta_title); ?></td>
                        <td><?php echo e($brand->meta_description); ?></td>
                        <td><?php echo e($brand->meta_keywords); ?></td>
                        <td>
                            <a href="<?php echo e(route('brands.show', $brand->id)); ?>" class="btn btn-sm btn-info">View</a>
                            <a href="<?php echo e(route('brands.edit', $brand->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('brands.destroy', $brand->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this brand?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/brands/index.blade.php ENDPATH**/ ?>