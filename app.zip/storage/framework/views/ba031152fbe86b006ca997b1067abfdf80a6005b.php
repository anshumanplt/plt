<!-- resources/views/admin/users/show.blade.php -->

 

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="container">
            <h1>Admin User Details</h1>
            <p><strong>Name:</strong> <?php echo e($adminUser->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($adminUser->email); ?></p>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/admin/users/show.blade.php ENDPATH**/ ?>