<!-- resources/views/attributes/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Attribute Details</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($attribute->name); ?></h5>

                <div class="mb-3">
                    <label class="fw-bold">ID:</label>
                    <span><?php echo e($attribute->id); ?></span>
                </div>

                <a href="<?php echo e(route('attributes.edit', $attribute->id)); ?>" class="btn btn-primary">Edit</a>
                <a href="<?php echo e(route('attributes.index')); ?>" class="btn btn-secondary">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/attributes/show.blade.php ENDPATH**/ ?>