
<?php $__env->startSection('content'); ?>

    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a>
                        <span>Shopping cart</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Shop Cart Section Begin -->
    <section class="shop-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Flash messages -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="shop__cart__table">
                        <?php if(count($cartItems) == 0): ?>
                            <center><h3>Your cart is empty.</h3></center>
                        <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    
                                    <th>Product</th>
                                    
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $cartTotal = 0;  
                                ?>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="cart__product__item">
                                        
                                        <?php if(count($cartItem->images) > 0): ?>
                                            <img src="<?php if(count($cartItem->images) > 0): ?> <?php echo e(asset('../storage/app/public/'.$cartItem->images[0]->image_path)); ?><?php endif; ?>" alt="Product Image" width="50">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                        <div class="cart__product__item__title">
                                            <h6><?php echo e($cartItem->name); ?></h6>
                                            
                                        </div>
                                    </td>

                                    <td class="cart__quantity">
                                        
                                            
                                            <form action="<?php echo e(route('cart.update', $cartItem->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>                            
                                                <input type="hidden" name="_method" value="PUT">                            
                                                <input type="number" name="quantity" value="<?php echo e($cartItem->quantity); ?>" class="col-sm-4" min="1" fdprocessedid="k2zmpw">
                                                <button type="submit" fdprocessedid="bn3unn" class="btn btn-primary btn-xs">Update</button>
                                            </form>
                                        
                                    </td>
                                    <td class="cart__price">₹ <?php echo e($cartItem->sale_price); ?></td>
                                    <td class="cart__total">₹ <?php echo e($cartItem->quantity * $cartItem->sale_price); ?></td>
                                    <td class="cart__close"> <a href="<?php echo e(route('cart.remove', $cartItem->id)); ?>"><span class="icon_close"></span></a></td>
                                </tr>
                                <?php
                                    $cartTotal += $cartItem->sale_price * $cartItem->quantity; // Update cart total
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(count($cartItems) > 0): ?>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="cart__btn">
                        <a href="<?php echo e(url('/')); ?>">Continue Shopping</a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    
                </div>
                <div class="col-lg-4 offset-lg-2">
                    <div class="cart__total__procced">
                        <h6>Cart total</h6>
                        <ul>
                            <li>Subtotal <span>₹ <?php echo e($cartTotal); ?></span></li>
                            <li>Total <span>₹ <?php echo e($cartTotal); ?></span></li>
                        </ul>
                        <a href="<?php echo e(url('checkout')); ?>" class="primary-btn">Proceed to checkout</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <!-- Shop Cart Section End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/cart/index.blade.php ENDPATH**/ ?>