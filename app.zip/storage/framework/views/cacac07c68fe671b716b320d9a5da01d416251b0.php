

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__links">
                        <a href="./index.html"><i class="fa fa-home"></i> Home</a>
                        <span>Shopping cart</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Checkout Section Begin -->
    <section class="checkout spad">
         <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h6 class="coupon__link">
                    
                 </h6>
            </div>
        </div>
        <?php if(!$addresses->isEmpty()): ?>
        <h3>Selected Address</h3>
        <div class="row">
            <div class="col-sm-12">
            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-sm-4" style="float: right">
                <div class="card-body">
                    <table class="table-borderless">
                        <tr>
                            <td><b>Address1:</b></td>
                            <td><?php echo e($address->address1); ?></td>
                        </tr>
                        <tr>
                            <td><b>Address2:</b></td>
                            <td><?php echo e($address->address2); ?></td>
                        </tr>
                        <tr>
                            <td><b>Mobile:</b></td>
                            <td><?php echo e($address->mobile); ?></td>
                        </tr>
                        <tr>
                            <td><b>Postal:</b></td>
                            <td><?php echo e($address->pin); ?></td>
                        </tr>
                        <tr>
                            <td><b>City:</b></td>
                            <td>
                                <?php 
                                    $cityData = App\Models\City::where('id', $address->city)->first();
                                    echo $cityData->name;
                                ?>
                                </td>
                        </tr>
                        <tr>
                            <td><b>State:</b></td>
                            <td>
                                <?php 
                                    $stateData = App\Models\State::where('id', $address->state)->first();
                                    echo $stateData->name;
                                ?>
                                
                            </td>
                        </tr>
                        <tr>
                            <td><b>Country:</b></td>
                            <td>
                                <?php 
                                    $countryData = App\Models\Country::where('id',$address->country)->first();
                                    echo $countryData->name;
                                ?>
                              
                            </td>
                        </tr>
                        <tr>
                            <td><b>Default Address:</b></td>
                            <td>
                                <?php if($address->is_default): ?> 
                                    <input type="radio" <?php if($address->is_default): ?> checked <?php endif; ?>>
                                    <?php else: ?>
                                    <form action="<?php echo e(route('addresses.set-default', $address->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit">Set as Default</button>
                                    </form>
                                <?php endif; ?>
                           
                            </td>
                        </tr>
                    </table>
               
                </div>
            </div>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('checkout.addAddress')); ?>" method="POST" class="checkout__form">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-8">
                    <h5>Shipping detail</h5>
                    <div class="row">
                
                        <div class="col-lg-12">
                          
                            <div class="checkout__form__input">
                                <p>Address <span>*</span></p>
                                <input type="text" name="address1" required placeholder="Address 1">
                                <input type="text" name="address2"  placeholder="Address 2 ( optinal )">
                            </div>
                            <div class="checkout__form__input">
                                <p>Country <span>*</span></p>
                                
                                 <select name="country" id="country_id" required class="form-control" id="">
                                    <option value="">--Select Country--</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="checkout__form__input">
                                <p>State <span>*</span></p>
                                
                                <select id="state_id" required class="form-control" name="state">
                                    <!-- Options for states... -->
                                </select>
                            </div>
                            <div class="checkout__form__input">
                                <p>Town/City <span>*</span></p>
                                
                                 <select id="city_id" required class="form-control" name="city">
                                    <!-- Options for cities... -->
                                </select>
                            </div>
                        
                            <div class="checkout__form__input">
                                <p>Postcode/Zip <span>*</span></p>
                                <input name="pin" required type="text">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="checkout__form__input">
                                <p>Phone <span>*</span></p>
                                <input name="mobile" type="text">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="checkout__form__input">
                                
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <input type="submit" class="btn btn-danger" value="Add Address">
                        </div>
                    </form>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="checkout__order">
                            <h5>Your order</h5>
                            <div class="checkout__order__product">
                                <ul>
                                    <li>
                                        <span class="top__text">Product</span>
                                        <span class="top__text__right">Total</span>
                                    </li>
                                    <?php
                                        $cartTotal = 0;  
                                    ?>
                                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($key + 1); ?>. <?php echo e($cartItem->product->name); ?> <span>₹ <?php echo e($cartItem->product->sale_price); ?> * <?php echo e($cartItem->quantity); ?></span></li>
                                    <?php
                                        $cartTotal += $cartItem->product->sale_price * $cartItem->quantity; // Update cart total
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                            <div class="checkout__order__total">
                                <ul>
                                    <li>Subtotal <span>₹ <?php echo e($cartTotal); ?></span></li>
                                    <li>Total <span>₹ <?php echo e($cartTotal); ?></span></li>
                                </ul>
                            </div>
                            <form action="<?php echo e(route('orders.place-order')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            <div class="checkout__order__widget">
                                
                                <label for="paypal">
                                    Cash on delivery
                                    <input type="checkbox" id="" checked name="payment_method" value="cod">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <button type="submit" class="site-btn">Place oder</button>
                            </form>
                        </div>
                    </div>
                </div>
            
        </div>
    </section>
        <!-- Checkout Section End -->







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/checkout/index.blade.php ENDPATH**/ ?>