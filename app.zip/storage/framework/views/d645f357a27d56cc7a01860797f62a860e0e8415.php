<nav class="myaccount-nav" style="padding-top: 10%; border: none;">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/my-account')); ?>">Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Route::is('orders.index') ? 'active' : ''); ?>" href="<?php echo e(route('orders.index')); ?>">Orders</a>
        </li>
        <!-- Add more links as needed -->
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/myaccount_sidebar.blade.php ENDPATH**/ ?>