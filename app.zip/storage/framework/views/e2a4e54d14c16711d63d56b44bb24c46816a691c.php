<!-- resources/views/attributes/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Attributes</h1>

        <a href="<?php echo e(route('attributes.create')); ?>" class="btn btn-primary">Create New Attribute</a>

        <table class="table mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attribute->id); ?></td>
                        <td><?php echo e($attribute->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('attributes.show', $attribute->id)); ?>" class="btn btn-sm btn-info">View</a>
                            <a href="<?php echo e(route('attributes.edit', $attribute->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('attributes.destroy', $attribute->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this attribute?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div></div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/attributes/index.blade.php ENDPATH**/ ?>