<!-- resources/views/attribute_values/edit.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Edit Attribute Value</h1>

        <form action="<?php echo e(route('attribute_values.update', $attributeValue->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="attribute_id">Attribute</label>
                <select name="attribute_id" id="attribute_id" class="form-control" required>
                    <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($attribute->id); ?>" <?php echo e($attributeValue->attribute_id == $attribute->id ? 'selected' : ''); ?>><?php echo e($attribute->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="value">Value</label>
                <input type="text" name="value" id="value" class="form-control" value="<?php echo e($attributeValue->value); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/attribute_values/edit.blade.php ENDPATH**/ ?>