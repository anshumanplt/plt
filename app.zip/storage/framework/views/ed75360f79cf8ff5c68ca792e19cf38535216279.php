<!-- resources/views/products/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
    <div class="container">
        <h1>Products</h1>

        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Create New Product</a>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>SKU</th>
                    <th style="width: 50px;">Name</th>
                    
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->sku); ?></td>
                        <td style="width: 50px;"><?php echo e($product->name); ?></td>
                        
                        <td><?php echo e($product->category->name); ?></td>
                        <td><?php echo e($product->subcategory->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->status ? 'Active' : 'Inactive'); ?></td>
                        <td>
                            <a href="<?php echo e(route('products.show', $product->id)); ?>"><span class="mdi mdi-eye-circle"></span></a>
                            <a href="<?php echo e(route('products.edit', $product->id)); ?>"><span class="mdi mdi-pencil-box"></span></a>
                            <a href="<?php echo e(route('products.images.index', $product->id)); ?>" ><span class="mdi mdi-image-multiple"></span></a><br>
                            <a href="<?php echo e(route('product-attributes.index', $product->id)); ?>"><span class="mdi mdi-ticket"></span></a>
                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Are you sure you want to delete this product?')"><span class="mdi mdi-delete"></span></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->links('pagination::bootstrap-4')); ?>

    </div>
    </div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/products/index.blade.php ENDPATH**/ ?>