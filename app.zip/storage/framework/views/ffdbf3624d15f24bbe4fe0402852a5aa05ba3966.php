<!-- resources/views/categories/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Category Details</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($category->name); ?></h5>

                <div class="mb-3">
                    <label class="fw-bold">Category ID:</label>
                    <span><?php echo e($category->category_id); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Image:</label>
                    <?php if($category->image): ?>
                        <img src="<?php echo e(asset('images/' . $category->image)); ?>" alt="Category Image" width="200">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Parent Category:</label>
                    <span><?php echo e($category->parentCategory ? $category->parentCategory->name : 'None'); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Title:</label>
                    <span><?php echo e($category->meta_title); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Description:</label>
                    <span><?php echo e($category->meta_description); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Meta Keywords:</label>
                    <span><?php echo e($category->meta_keywords); ?></span>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">Status:</label>
                    <span><?php echo e($category->status ? 'Active' : 'Inactive'); ?></span>
                </div>

                <a href="<?php echo e(route('categories.edit', $category->category_id)); ?>" class="btn btn-primary">Edit</a>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomp\resources\views/categories/show.blade.php ENDPATH**/ ?>